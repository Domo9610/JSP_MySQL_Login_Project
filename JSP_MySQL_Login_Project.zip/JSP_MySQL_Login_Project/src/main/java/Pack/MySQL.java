package Pack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class MySQL {
	private Connection conn; //DB Ŀ�ؼ� ���� ��ü
	private final String USERNAME = "root";//DBMS���� �� ���̵�
	private final String PASSWORD = "1234";//DBMS���� �� ��й�ȣ
	private final String URL = "jdbc:mysql://localhost:3306/db01";//DBMS������ db��

	public MySQL() {
		try {
			System.out.println("[ ������ ]");
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("[ ����̹� �ε� ���� ]");
		} catch (Exception e) {
			System.out.println("[ ����̹� �ε� ���� ]");
			try {
				conn.close();
			} catch (SQLException e1) {    }
		}
	}

	public void create(String a, int b, int c) {
		String sql = "insert into table01 values(?,?,?)";

		PreparedStatement pstmt = null;
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, a); //FullName
			pstmt.setInt(2, b); // Age
			pstmt.setInt(3, c); // Salary

			int result = pstmt.executeUpdate();
			if(result == 1) {
				System.out.println("[ Create �޼��� ���� ���� ]");
			}

		}catch (Exception e) {
			System.out.println("[ Create �޼��� ���� ���� ]");
		}    finally {
			try {
				if(pstmt!=null && !pstmt.isClosed()) {
					pstmt.close();
					return;
				}
			} catch (Exception e2) {}
		}


	}

	public void read() {
		String sql = " select * from table01 ";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				System.out.println("Name: " + rs.getString("FullName"));
				System.out.println("Age: " + rs.getInt("Age"));
				System.out.println("Salary: " + rs.getInt("Salary"));
				System.out.println("-----------------------------------");
			}

		}
		catch(Exception e) {
			System.out.println("[ select �޼��� ���ܹ߻� ]");
		}    finally {
			try {
				if(pstmt!=null && !pstmt.isClosed()) {
					pstmt.close();
					return;
				}
			} catch (Exception e2) {}
		}

	}

	public void update(String a, int b, int c) {
		String sql = "update table01 set Age=?, Salary=? where FullName=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,b);
			pstmt.setInt(2,c);
			pstmt.setString(3,a);
			pstmt.executeUpdate();
			System.out.println("[ Name : " + a + "������ ]");

		} catch (Exception e) {
			System.out.println("[ update �޼��� ���� �߻� ] ");
		}    finally {
			try {
				if(pstmt!=null && !pstmt.isClosed()) {
					pstmt.close();
					return;
				}
			} catch (Exception e2) {}
		}
	}


	public void delete(String a) {
		String sql = "Delete from table01 where FullName= ? ";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,a);
			pstmt.executeUpdate();
			System.out.println("[ Name : " + a + " ������ ]");

		} catch (Exception e) {
			System.out.println("[ update �޼��� ���� �߻� ] ");
		}    finally {
			try {
				if(pstmt!=null && !pstmt.isClosed()) {
					pstmt.close();
					return;
				}
			} catch (Exception e2) {}
		}
	}
}


